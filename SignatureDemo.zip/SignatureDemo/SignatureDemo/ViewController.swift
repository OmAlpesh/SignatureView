//
//  ViewController.swift
//  SignatureDemo
//
//  Created by Admin on 26/03/19.
//  Copyright © 2019 alpesh. All rights reserved.
//

import UIKit

class ViewController: UIViewController, YPSignatureDelegate {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var signatureView: YPDrawSignatureView!
    
    
    @IBOutlet weak var View6: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
         signatureView.delegate = self
        scrollView.isScrollEnabled = true
    }

    
    // Function for clearing the content of signature view
    @IBAction func clearSignature(_ sender: UIButton) {
        // This is how the signature gets cleared
        self.signatureView.clear()
    }
    
    // Function for saving signature
    @IBAction func saveSignature(_ sender: UIButton) {
        // Getting the Signature Image from self.drawSignatureView using the method getSignature().
        if let signatureImage = self.signatureView.getSignature(scale: 10) {
            
            // Saving signatureImage from the line above to the Photo Roll.
            // The first time you do this, the app asks for access to your pictures.
            UIImageWriteToSavedPhotosAlbum(signatureImage, nil, nil, nil)
            
            // Since the Signature is now saved to the Photo Roll, the View can be cleared anyway.
            self.signatureView.clear()
        }
    }
    
    
    func didStart(_ view : YPDrawSignatureView) {
        print("Started Drawing")
        scrollView.isScrollEnabled = false
    }
    
    
    
    // didFinish() is called rigth after the last touch of a gesture is registered in the view.
    // Can be used to enabe scrolling in a scroll view if it has previous been disabled.
    func didFinish(_ view : YPDrawSignatureView) {
        print("Finished Drawing")
        scrollView.isScrollEnabled = true
    }

    func didMove(_ view: YPDrawSignatureView) {
        scrollView.isScrollEnabled = false
    }
}

